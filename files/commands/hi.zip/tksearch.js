import message from "./message.js";
import react from "./react.js";

async function tiktoksearch(m, client){const messageBody = m.message?.extendedTextMessage?.text || message.message?.conversation || '';

    const commandAndArgs = messageBody.slice(1).trim();

    const parts = commandAndArgs.split(/\s+/);

    const args = parts.slice(1);


    if (!args[0]) {
      return await message.replyToMessage(m,client,{text:"😆 What do you want to search on TikTok?\n\n*Usage Example:*\n.tiktoksearch query"});
    }
  
    const query = args.join(" ");

    await react(m,client,'⌛');
  
    try {
      await message.replyToMessage(m,client,{text:`🔎 Searching TikTok for: *${query}*`});
      
      const response = await fetch(`https://api.diioffc.web.id/api/search/tiktok?query=${encodeURIComponent(query)}`);
      const data = await response.json();
  
      if (!data || !data.status || !data.result || data.result.length === 0) {
        await react(m,client,'❌');
        return await message.replyToMessage(m,client,{text:"> ❌ No results found for your query. Please try with a different keyword."});
      }
  
      // Get up to 7 random results
      const results = data.result.slice(0, 7).sort(() => Math.random() - 0.5);
  
      for (const video of results) {
        const msg = `🎶 *TikTok Video Result*:\n\n`
          + `*• Title*: ${video.title}\n`
          + `*• Author*: ${video.author.name || 'Unknown'} (@${video.author.username})\n`
          + `*• Duration*: ${video.duration}s\n`
          + `*• Plays*: ${video.stats.play}\n`
          + `*• Likes*: ${video.stats.like}\n`
          + `*• URL*: https://www.tiktok.com/@${video.author.username}/video/${video.video_id}\n\n`;
  
        if (video.media.no_watermark) {
          await message.replyToMessage(m,client, {
            video: { url: video.media.no_watermark }, 
            caption: msg
          }, { quoted: m });
        } else {
          await message.replyToMessage(m,client,{text:`❌ Failed to retrieve video for *"${video.title}"*.`});
        }
      }
  
      await react(m,client,'✅');
    } catch (error) {
      console.error("Error in TikTokSearch command:", error);

      await react(m,client,'❌');

      await message.replyToMessage(m,client,{text:"❌ An error occurred while searching TikTok. Please try again later."});
    }}

export default tiktoksearch
    