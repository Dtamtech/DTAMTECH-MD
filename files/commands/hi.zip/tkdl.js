import message from "./message.js";
import  react  from "./react.js";

async function tkdown(m, client) {
    try {

        const remoteJid = message.key.remoteJid;

        const commandAndArgs = messageBody.slice(1).trim();

        const parts = commandAndArgs.split(/\s+/);

        const args = parts.slice(1);

        const url = args[0];

        if (!url || !url.startsWith("http")) {
          return message.replyToMessage(m, client,"Please provide a valid TikTok link.\n\n*Usage Example:*\n\n.tt2 <TikTok video URL>");
        }
        const result = await fetch('https://api.yanzbotz.live/api/downloader/tiktok?url=' + encodeURIComponent(url) + "&apiKey=yanzdev");
        const resultJson = await result.json();
        if (!resultJson || !resultJson.result) {
          return message.replyToMessage(m, client,"Sorry, I couldn't fetch the TikTok content. Please check the link and try again.");
        }
        const trueResult = resultJson.result;
        const vidCaption = "╭━━━〔 *DTAMTECH-MD* 〕━━━┈⊷\n┃▸╭───────────\n┃▸┃๏ *TIKTOK DOWNLOADER*\n┃▸└───────────···๏\n╰────────────────┈⊷\n╭━━〔 *Post Details* 〕━━┈⊷\n┇๏ *Type:* " + (trueResult.type || "N/A") + "\n┇๏ *Name:* " + (trueResult.name || "N/A") + "\n┇๏ *Username:* " + (trueResult.username || 'N/A') + "\n┇๏ *Views:* " + (trueResult.views || 0x0) + "\n┇๏ *Likes:* " + (trueResult.likes || 0x0) + "\n┇๏ *Comments:* " + (trueResult.comments || 0x0) + "\n┇๏ *Favorites:* " + (trueResult.favorite || 0x0) + "\n┇๏ *Shares:* " + (trueResult.shares || 0x0) + "    \n┇๏ *Description:* " + (trueResult.description || "N/A") + "    \n╰━━━━━━━━━━━━──┈⊷\n> © DTAMTECH ✅";
        if (trueResult.type === "video") {
          await client.sendMessage(remoteJid, {
            'video': {
              'url': trueResult.video["no-watermark"]
            },
            'caption': vidCaption
          }, {
            'quoted': m
          });
        } else {
          if (trueResult.type === "image") {
            for (const [_0x1ac338, _0x5746de] of (trueResult.image || []).entries()) {
              await client.sendMessage(remoteJid, {
                'image': {
                  'url': _0x5746de
                },
                'caption': "*💜 Image:* " + (_0x1ac338 + 0x1) + "\n\n" + vidCaption
              }, {
                'quoted': m
              });
            }
          } else {
            return message.replyToMessage(m, client,"Sorry, I couldn't process this type of TikTok content.");
          }
        }
      } catch (error) {
        console.error("Error in TikTok command:", error);
        message.replyToMessage(m, client,"An error occurred while processing your request. Please try again later.");
      }
}

export default tkdown
